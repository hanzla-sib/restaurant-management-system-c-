#include<iostream>
#include<unistd.h>
#include<fcntl.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<cstring>
#include<pthread.h>
using namespace std;
pthread_mutex_t mutex1;
pthread_t thread1;
float daily_sales=0;
char data[30]="please show me the menu...";
void *THREAD(void*)
{

 while(1){  
    // pthread_mutex_lock ( &mutex1 );
    

    

    int fd1,fd2,fd3;
    char buffwrite[20];
    int time=0;
    char id[20];
    char name[20];
    char msg[50];
    char option[10];
    char frequency[10];
    char menu[1000]="The menu is:\n\n   dish_name\t\tprice \t\tpreparing_Time\n\n1) pizza    \t\t500RS \t\t5 sec\n2) Handi     \t\t1000Rs\t\t6 sec\n3) Karahi   \t\t1000RS \t\t5 sec\n4) Shawarma \t\t100RS \t\t3 sec\n5) MilkShake\t\t200RS \t\t2 sec\n6) naan     \t\t20RS  \t\t1 sec"; 
    fd1=open("FIRSTPIPE",O_RDONLY);          // Writing Pipe
    fd2=open("SECONDPIPE",O_WRONLY);        // Reading Pipe
    fd3=open("THIRDPIPE",O_WRONLY);
        int len=read(fd1,name,sizeof(name));
        name[len]='\0';
        cout<<"Customer's Name is:"<<name<<endl;
        int len2=read(fd1,id,sizeof(id));
	id[len2]='\0';
	cout<<"Customer's ID is:"<<id<<endl;
	// int len3=read(fd1,msg,sizeof(msg));
 //        msg[len3]='\0';
 //        cout<<endl<<msg<<endl;
	cout<<data<<endl;
	close(fd1);
	//fd2=open("SECONDPIPE",O_WRONLY); 
        write(fd2,menu,strlen(menu));
	//close(fd2);
	fd1=open("FIRSTPIPE",O_RDONLY);
	int len4=read(fd1,option,sizeof(option));
        option[len4]='\0';
        cout<<"Options : "<<option<<endl;
        cout<<"Customer's selected option:"<<option<<endl;
	write(fd3,option,strlen(option));
	
	int amount=0;
	close(fd1);
	int j=0;
	while(j<9&&option[j+1]!='\0')
	{
	if(option[j]=='1')
	{
		
	cout<<"1 x Pizza"<<endl;
	amount=amount+500;
	char food[100]="Pizza";
	time=time+5;
	
	}
	else if(option[j]=='2')
	{
	amount=amount+1000;	
	cout<<"1 x Handi"<<endl;
	time=time+6;
	}
	else if(option[j]=='3')
	{
	amount=amount+1000;	
	cout<<"1 x Karahi"<<endl;
	time=time+5;
	}
	else if(option[j]=='4')
	{
	amount=amount+100;	
	cout<<"1 x Shawarma"<<endl;
	time=time+3;
	}
	else if(option[j]=='5')
	{
	amount=amount+200;	
	cout<<"1 x MilkShake"<<endl;
	time=time+2;
	}
	else if(option[j]=='6')
	{
	amount=amount+20;	
	cout<<"1 x Naan"<<endl;
	time=time+1;
	}
	else if(option[j]=='0')
	{
	break;
	}
	else{
	cout<<"No such food in our menu"<<endl; 
	}
	j++;
	}
       cout<<"Total bill: "<<amount<<endl;
       daily_sales+=amount;
	string str=to_string(amount);
	const char* bill=str.c_str();
	cout<<"Bill is "<<bill<<endl;	
	cout<<"DAILY_SALES = "<<daily_sales<<endl;
	// string ti=to_string(time);
	// const char* tim=ti.c_str();
	// write(fd2,(void*)tim,sizeof(tim));
	
    // close(fd1);
    close(fd2);
// pthread_mutex_unlock ( &mutex1 ) ;
}
//pthread_exit (NULL);
}

int main() {
int i=5;
mkfifo("THIRDPIPE",0666);
pthread_mutex_init(&mutex1,NULL ) ;
pthread_create(&thread1 ,NULL,&THREAD ,NULL ) ;
pthread_join(thread1,NULL);

//pthread_exit (NULL) ;
unlink("THIRDPIPE");
pthread_mutex_destroy (&mutex1 );

//}
}
