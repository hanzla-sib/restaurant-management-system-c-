#include<iostream>
#include<unistd.h>
#include<fcntl.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<cstring>
#include<pthread.h>
#include<semaphore.h>
#include<sstream>  
using namespace std;
pthread_mutex_t mutex1;

sem_t sem;
sem_t sem1;
sem_t sem2;
sem_t sem3;
char option[10];
int ind=0;
int counter=0;
int len;

int price=0;

void* Again(void* a)
{
	while(1)
	{
		int fd1,fd2;
		fd1=open("THIRDPIPE",O_RDONLY);

		len=read(fd1,option,10);
		option[len]='\0';
		bool flag=0;
		for(int i=0;i<10;i++)
		{
			if(option[i]=='0')
				flag=1;
			if(flag)
				option[i]='\0';

		}
	}
}

void *Cook(void* c)
{
	sleep(2);
	while(1)
	{
		bool breaker=0;
		if(option[0]!='0')
		{

			int index = 0 ;
			while(index<10)
			{	
				sem_wait(&sem1);
				
				index = ind;
				if(index<9)
				ind++;
				sem_post(&sem1);
				if(option[index]=='0' || option[index]=='\0' || index>9)
				{
					breaker=1;
					break;
				}
				cout<<"Customer's Order is:"<<option[index]<<endl;
				if(option[index]=='1')
				{	
					price+=500;
					sleep(5);
					counter++;
					cout<<"Pizza Prepared\n";
					 
				}
				else if(option[index]=='2')
				{	price+=1000;
					sleep(6);	
					counter++;
					cout<<"Handi Prepared"<<endl;
					 
				}
				else if(option[index]=='3')
				{
					price+=1000;
					sleep(5);
					counter++;	
					cout<<"Karahi Prepared"<<endl;
					 
				}
				else if(option[index]=='4')
				{
					price+=100;
					sleep(3);	
					counter++;
					cout<<"Shawarma Prepared"<<endl;
					 
				}
				else if(option[index]=='5')
				{
					price+=200;
					sleep(2);
					counter++;	
					cout<<"MilkShake Prepared"<<endl;
					 
				}
				else if(option[index]=='6')
				{
					price+=20;
					sleep(1);	
					counter++;
					cout<<"Naan Prepared"<<endl;
					 
				}
				else if(option[index]=='0' || option[index]=='\0')
				{
					breaker=1;
					break;
				}
				else
				{
					cout<<"No such food in our menu"<<endl; 
				}

			}
		}
		
		sem_wait(&sem1);
			if(option[ind]=='0')
			ind=0;
			
		sem_post(&sem1);
		char status[10]="Prepared";
		//if(counter==len-2)
		if(breaker)
		{	
			for(int i=0;i<10;i++)
				option[i]='0';
			sem_wait(&sem);
			string str=to_string(price);
			const char* bill=str.c_str();
			//cout<<"price "<<price<<endl;
			price=0;
			int fd1,fd2;
			fd2=open("FOURTHPIPE",O_WRONLY);
			write(fd2,status,strlen(status));
		    write(fd2,bill,strlen(bill));

			close(fd2);
			sem_post(&sem);
		
		}
	}

	//pthread_exit (NULL);
}
int main() {
	int c;
int w;

cout<<"enter the number of cooks"<<endl;
cin>>c;

pthread_t thread1[c] ,thread2;
//pthread_attr_t attr;
sem_init (&sem , 0 , 1 ) ;
sem_init (&sem1 , 0 , 1 ) ;
sem_init (&sem2 , 0 , 1 ) ;
sem_init (&sem3 , 0 , 1 ) ;

for(int i=0;i<10;i++)
	option[i]='0';
pthread_create(&thread2 ,NULL,&Again ,NULL);
int* st=new int;
int counter=0;

while(counter<c){
sem_wait(&sem3);

pthread_create(&thread1[counter] ,NULL,&Cook ,(void*)st );
counter++;
sem_post(&sem3);
}

for(int i=0;i<c;i++){
	pthread_join(thread1[i],NULL);
}



}

