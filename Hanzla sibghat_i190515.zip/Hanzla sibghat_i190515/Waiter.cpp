#include<iostream>
#include<unistd.h>
#include<fcntl.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<cstring>
#include<pthread.h>
#include<semaphore.h>
using namespace std;
pthread_mutex_t mutex1;
pthread_t thread1;
int Daily_Waiter_Sales=0;
void *Waiter(void*)
{
    while(1)
    {
     
    //    pthread_mutex_lock ( &mutex1 );
        int fd1,fd2,fd3;
        char option[10];
        fd1=open("FOURTHPIPE",O_RDONLY);
        char status[10];
        char ss[7];
        char confirmation[100];
        int len=read(fd1,status,sizeof(status));
        string final;
        status[len]='\0';
         int len1=read(fd1,ss,sizeof(ss));

         ss[len1]='\0';
         final=ss;
        int convert=stoi(final);
        Daily_Waiter_Sales+=convert;
        if(!strncmp(status,"Prepared",8))
        {
            cout<<"Customer's Order : "<<status<<endl;

            cout<<"Delivering the order to the customer"<<endl;
            sleep(3);
            char msg[100]="ORDER DELIVERED SUCCESSFULLY";
            cout<<"total "<<ss<<endl;
            cout<<"Daily_Waiter_Sales = "<<Daily_Waiter_Sales<<endl;
            
            fd2=open("FIFTHPIPE",O_WRONLY);
            write(fd2,msg,strlen(msg));
            fd3=open("SIXTHPIPE",O_RDONLY);
            int len2=read(fd3,confirmation,sizeof(confirmation));
            confirmation[len2]='\0';

            cout<<"Customer's Order : "<<confirmation<<endl;

            close(fd2);
            close(fd3);
        }
        close(fd1);

    //    pthread_mutex_unlock ( &mutex1 ) ;
    }
//pthread_exit (NULL);
}
int main() {
    mkfifo("FIFTHPIPE",0666);
 mkfifo("FOURTHPIPE",0666);
pthread_mutex_init(&mutex1,NULL ) ;
pthread_create(&thread1 ,NULL,&Waiter ,NULL ) ;
pthread_join(thread1,NULL);
//pthread_exit (NULL) ;

    unlink("FIFTHPIPE");
    unlink("FOURTHPIPE");
pthread_mutex_destroy (&mutex1 );
}

