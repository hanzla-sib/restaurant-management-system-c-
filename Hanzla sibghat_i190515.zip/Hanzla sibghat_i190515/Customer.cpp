#include<iostream>
#include<unistd.h>
#include<fcntl.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<cstring>
#include<pthread.h>
using namespace std;

void *Customer(void*)
{
char name[20];
char id[20];
char msg[50]="please show me the menu...";
char bufferread[20];
char menu[1000];
char option[10];
char frequency[10];
char tim[5];
for(int i=0;i<5;i++){
	tim[i]='\0';
}
char status[100];
int fd1,fd2,fd3,fd4;
   

    fd1=open("FIRSTPIPE",O_WRONLY);          // Writing Pipe
    fd2=open("SECONDPIPE",O_RDONLY);        // Reading Pipe
    
    
        cout<<"Please Enter your name:";
        cin>>name;

        write(fd1,name,strlen(name));

	// close(fd1);
	fd1=open("FIRSTPIPE",O_WRONLY);  
	cout<<"Please Enter Your ID:";
	cin>>id;
	write(fd1,id,strlen(id));
	close(fd1);
	// fd1=open("FIRSTPIPE",O_WRONLY);
	// write(fd1,msg,strlen(msg));
	// close(fd1);
        int i=read(fd2,menu,sizeof(menu));
        menu[i]='\0';
        cout<<"Menu:"<<menu<<endl;
	cout<<"Press 0 to complete your order."<<endl; 
	int j=0;
	while(j<8){
	cout<<"Please select a number from the menu.Press 0 to end your order"<<endl;
	cin>>option[j];
	if(option[j]=='0')
	{
	break;
	}
	j++;
	}
	fd1=open("FIRSTPIPE",O_WRONLY);
	write(fd1,option,strlen(option));
	close(fd1);
	// int k=read(fd2,tim,sizeof(tim));
	// tim[k]='\0';
 //        cout<<"Your time for preparation is: "<<tim<<endl;
	close(fd2);
	
	fd3=open("FIFTHPIPE",O_RDONLY);
	int l=read(fd3,status,sizeof(status));
	status[l]='\0';
        cout<<status<<endl;
close(fd3);
char confirmation[100]="ORDER RECEIVED SUCCESSFULLY";
fd4=open("SIXTHPIPE",O_WRONLY);
write(fd4,confirmation,strlen(confirmation));
close(fd4); 


}
int main() {
int customer;
 mkfifo("FIRSTPIPE",0666);
    mkfifo("SECONDPIPE",0666);
    mkfifo("SIXTHPIPE",0666);
cout<<"Please Enter the total Number of customers: "<<endl;
cin>>customer;

pthread_t thread[customer];
for(int i=0;i<customer;i++)
{
pthread_create(&thread[i] ,NULL,&Customer,NULL ) ;
pthread_join(thread[i],NULL);
}
    unlink("FIRSTPIPE");
    unlink("SECONDPIPE");
pthread_exit (NULL) ;
}



